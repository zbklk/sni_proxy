package main

import (
	"context"
	"encoding/binary"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"gopkg.in/yaml.v2"
)

var (
	version string // 编译时写入版本号

	ConfigFilePath string // 配置文件
	LogFilePath    string // 日志文件
	EnableDebug    bool   // 调试模式（详细日志）

	ForwardPort = 443       // 要转发至的目标端口
	cfg         configModel // 配置文件结构
)

// 配置文件结构
type configModel struct {
	ForwardRules   []string `yaml:"rules,omitempty"`
	ListenAddr     string   `yaml:"listen_addr,omitempty"`
	ListenAddrHTTP string   `yaml:"listen_addr_http,omitempty"`
	EnableSocks    bool     `yaml:"enable_socks5,omitempty"`
	SocksAddr      string   `yaml:"socks_addr,omitempty"`
	SocksUsername  string   `yaml:"socks_username,omitempty"`
	SocksPassword  string   `yaml:"socks_password,omitempty"`
	AllowAllHosts  bool     `yaml:"allow_all_hosts,omitempty"`
}

func init() {
	var printVersion bool
	var help = `
SNIProxy ` + version + `
https://github.com/XIU2/SNIProxy

参数：
    -c config.yaml
        配置文件 (默认 config.yaml)
    -l sni.log
        日志文件 (默认 无)
    -d
        调试模式 (默认 关)
    -v
        程序版本
    -h
        帮助说明
`
	flag.StringVar(&ConfigFilePath, "c", "config.yaml", "配置文件")
	flag.StringVar(&LogFilePath, "l", "", "日志文件")
	flag.BoolVar(&EnableDebug, "d", false, "调试模式")
	flag.BoolVar(&printVersion, "v", false, "程序版本")
	flag.Usage = func() { fmt.Print(help) }
	flag.Parse()
	if printVersion {
		fmt.Printf("XIU2/SNIProxy %s\n", version)
		os.Exit(0)
	}
}

func main() {
	data, err := os.ReadFile(ConfigFilePath) // 读取配置文件
	if err != nil {
		serviceLogger(fmt.Sprintf("配置文件读取失败: %v", err), 31, false)
		os.Exit(1)
	}
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		serviceLogger(fmt.Sprintf("配置文件解析失败: %v", err), 31, false)
		os.Exit(1)
	}
	if len(cfg.ForwardRules) <= 0 && !cfg.AllowAllHosts { // 如果 rules 为空且 allow_all_hosts 不等于 true
		serviceLogger("配置文件中 rules 不能为空（除非 allow_all_hosts 等于 true）!", 31, false)
		os.Exit(1)
	}
	if len(cfg.ListenAddr) <= 0 {
		cfg.ListenAddr = ":443" // 如果没有指定 listen_addr 则默认监听 443 端口
	}
	for _, rule := range cfg.ForwardRules { // 输出规则中的所有域名
		serviceLogger(fmt.Sprintf("加载规则: %v", rule), 32, false)
	}
	serviceLogger(fmt.Sprintf("调试模式: %v", EnableDebug), 32, false)
	serviceLogger(fmt.Sprintf("前置代理: %v", cfg.EnableSocks), 32, false)
	serviceLogger(fmt.Sprintf("任意域名: %v", cfg.AllowAllHosts), 32, false)

	startSniProxy() // 启动 SNI Proxy
}

// 启动 SNI Proxy
func startSniProxy() {
	_, cancel := context.WithCancel(context.Background())
	defer cancel()

	// 如果配置了 listen_addr_http，则启动 HTTP 监听（用于 301 重定向至 HTTPS）
	if cfg.ListenAddrHTTP != "" {
		listenerHTTP, err := net.Listen("tcp", cfg.ListenAddrHTTP)
		if err != nil {
			serviceLogger(fmt.Sprintf("监听失败(HTTP): %s -> %v", cfg.ListenAddrHTTP, err), 31, false)
			os.Exit(1)
		}
		serviceLogger(fmt.Sprintf("开始监听: %v", listenerHTTP.Addr()), 0, false)

		go func(listenerHTTP net.Listener) {
			defer listenerHTTP.Close()
			for {
				conn, err := listenerHTTP.Accept()
				if err != nil {
					serviceLogger(fmt.Sprintf("接受连接请求时出错(HTTP): %v", err), 31, false)
					continue
				}
				raddr := conn.RemoteAddr().(*net.TCPAddr)
				serviceLogger("连接来自: "+raddr.String(), 32, false)
				go handleHTTPRedirect(conn) // 有新连接进来，启动一个新线程处理
			}
		}(listenerHTTP)
	}

	// 启动 HTTPS 监听
	listener, err := net.Listen("tcp", cfg.ListenAddr)
	if err != nil {
		serviceLogger(fmt.Sprintf("监听失败(HTTPS): %s -> %v", cfg.ListenAddrHTTP, err), 31, false)
		os.Exit(1)
	}
	serviceLogger(fmt.Sprintf("开始监听: %v", listener.Addr()), 0, false)

	go func(listener net.Listener) {
		defer listener.Close()
		for {
			conn, err := listener.Accept()
			if err != nil {
				serviceLogger(fmt.Sprintf("接受连接请求时出错(HTTPS): %v", err), 31, false)
				continue
			}
			raddr := conn.RemoteAddr().(*net.TCPAddr)
			serviceLogger("连接来自: "+raddr.String(), 32, false)
			go serve(conn, raddr.String()) // 有新连接进来，启动一个新线程处理
		}
	}(listener)

	// 收到终止信号时退出
	ch := make(chan os.Signal, 2)
	signal.Notify(ch, syscall.SIGINT, syscall.SIGTERM)
	s := <-ch
	cancel()
	fmt.Printf("\n接收到信号 %s, 退出.\n", s)
}

// 处理 HTTP 重定向至 HTTPS
func handleHTTPRedirect(conn net.Conn) {
	defer conn.Close()
	buf := make([]byte, 1024)
	n, err := conn.Read(buf)
	if err != nil || n == 0 {
		serviceLogger(fmt.Sprintf("读取连接请求时出错(HTTP): %v", err), 31, false)
		return
	}
	data := string(buf[:n])
	lines := strings.Split(data, "\r\n")
	if len(lines) == 0 {
		serviceLogger("不是 HTTP/1.1 消息", 31, true)
		return
	}
	// 解析请求行，获得路径
	reqLine := strings.Fields(lines[0])
	if len(reqLine) < 2 {
		serviceLogger("解析 HTTP/1.1 请求异常", 31, true)
		return
	}
	path := reqLine[1]
	// 解析 Host，获得域名
	var host string
	for _, line := range lines[1:] {
		if strings.HasPrefix(strings.ToLower(line), "host:") {
			host = strings.TrimSpace(line[5:])
			break
		}
	}
	// 如果没有 Host 或者 Host 为空，则不进行重定向，直接断开连接
	if host == "" {
		serviceLogger("未找到域名(HTTP), 忽略...", 31, true)
		return
	}

	if cfg.AllowAllHosts { // 如果 allow_all_hosts 为 true 则代表无需判断 http 域名
		sendHTTPRedirect(conn, host, path)
		return
	}
	for _, rule := range cfg.ForwardRules { // 循环遍历 Rules 中指定的白名单域名
		if strings.Contains(host, rule) { // 如果 http 域名中包含 Rule 白名单域名（例如 www.aa.com 中包含 aa.com）则重定向该 HTTP 连接为 HTTPS
			sendHTTPRedirect(conn, host, path)
			return
		} else {
			serviceLogger(fmt.Sprintf("域名 %s 不在允许域名列表中, 忽略(http)...", host), 31, false)
		}
	}
}

// 发送 301 跳转响应的函数
func sendHTTPRedirect(conn net.Conn, host, path string) {
	// 生成 301 重定向响应
	location := "https://" + host + path
	resp := fmt.Sprintf("HTTP/1.1 301 Moved Permanently\r\nLocation: %s\r\nConnection: close\r\nContent-Length: 0\r\n\r\n", location)
	serviceLogger(fmt.Sprintf("重定向至: %s", location), 34, false)
	// 发送响应
	_, err := conn.Write([]byte(resp))
	if err != nil {
		serviceLogger(fmt.Sprintf("无法传输到后端(HTTP), %v", err), 31, false)
	}
}

// 处理 HTTPS 新连接
func serve(conn net.Conn, raddr string) {
	defer conn.Close()

	buf := make([]byte, 2048)
	var fullHeader []byte
	const maxAttempts = 2
	attempts := 0

	for {
		n, err := conn.Read(buf)
		if err != nil && err != io.EOF {
			serviceLogger(fmt.Sprintf("读取连接请求时出错(HTTPS): %v", err), 31, false)
			return
		}
		fullHeader = append(fullHeader, buf[:n]...)

		if len(fullHeader) < 5 { // 判断是不是 TLS 握手消息
			serviceLogger("不是 TLS 握手消息", 31, true)
			return
		} else if IsCompleteHandshake(fullHeader) { // 检查是否已经接收到完整的 TLS 握手消息
			break // 如果已经完整，那么退出循环
		}

		attempts++
		if attempts >= maxAttempts {
			serviceLogger("接收握手消息超时...", 31, false)
			return // 如果超过最大等待次数，退出函数
		}
	}
	if attempts > 0 { // 如果等于 0 说明第一次就接收到了完整握手消息，如果大于 0 说明握手消息丢包或分段了
		serviceLogger("已接收到完整握手消息...", 32, true)
	}

	ServerName := getSNIServerName(fullHeader) // 获取 SNI 域名

	if ServerName == "" {
		serviceLogger("未找到 SNI 域名(HTTPS), 忽略...", 31, true)
		return
	}

	if cfg.AllowAllHosts { // 如果 allow_all_hosts 为 true 则代表无需判断 SNI 域名
		serviceLogger(fmt.Sprintf("转发目标: %s:%d", ServerName, ForwardPort), 32, false)
		forward(conn, fullHeader, fmt.Sprintf("%s:%d", ServerName, ForwardPort), raddr)
		return
	}

	for _, rule := range cfg.ForwardRules { // 循环遍历 Rules 中指定的白名单域名
		if strings.Contains(ServerName, rule) { // 如果 SNI 域名中包含 Rule 白名单域名（例如 www.aa.com 中包含 aa.com）则转发该连接
			serviceLogger(fmt.Sprintf("转发目标: %s:%d", ServerName, ForwardPort), 32, false)
			forward(conn, fullHeader, fmt.Sprintf("%s:%d", ServerName, ForwardPort), raddr)
		} else {
			serviceLogger(fmt.Sprintf("域名 %s 不在允许域名列表中, 忽略(https)...", ServerName), 31, false)
		}
	}
}

// 判断握手消息是否完整
func IsCompleteHandshake(header []byte) bool {
	Length := binary.BigEndian.Uint16(header[3:5])
	return len(header) >= int(Length)+5
}

// 获取 SNI 域名
func getSNIServerName(buf []byte) string {
	n := len(buf)
	if n < 5 {
		serviceLogger("不是 TLS 握手消息", 31, true)
		return ""
	}

	// TLS 记录类型
	if recordType(buf[0]) != recordTypeHandshake {
		serviceLogger("不是 TLS", 31, true)
		return ""
	}

	// TLS 主要版本
	if buf[1] != 3 {
		serviceLogger("不支持 TLS 版本 < 3", 31, true)
		return ""
	}

	// payload 长度
	//l := int(buf[3])<<16 + int(buf[4])
	//log.Printf("length: %d, got: %d", l, n)

	// 握手消息类型
	if buf[5] != typeClientHello {
		serviceLogger("不是 Client Hello 消息", 31, true)
		return ""
	}

	// 以下开始解析 Client Hello 消息
	msg := &clientHelloMsg{}
	// Client Hello 不包含 TLS 标头, 5 字节
	ret := msg.unmarshal(buf[5:n])
	if !ret {
		serviceLogger("解析 Client Hello 消息失败", 31, true)
		return ""
	}
	return msg.serverName
}

// forward 函数接收一个 net.Conn 类型的连接对象 conn、一个 []byte 类型的数据 data、一个目标地址 dst 和一个来源地址 raddr
// 该函数使用 GetDialer 函数创建一个与目标地址 dst 的后端连接 backend，将 data 写入 backend，然后使用 ioReflector 函数将 backend 和 conn 连接起来，以便将数据从一个连接转发到另一个连接
func forward(conn net.Conn, data []byte, dst string, raddr string) {
	// 建立后端连接前先做安全检查，避免把流量再次传回本机导致死循环
	if blocked, reason := shouldBlockForwardTarget(dst, raddr); blocked {
		serviceLogger(fmt.Sprintf("拒绝转发(HTTPS): \"%s\", 目标: [%s], 来源: [%s]", reason, dst, raddr), 31, false)
		return
	}

	backend, err := GetDialer(cfg.EnableSocks).Dial("tcp", dst)
	if err != nil {
		serviceLogger(fmt.Sprintf("无法连接到后端(HTTPS), %v", err), 31, false)
		return
	}

	defer backend.Close()

	if _, err = backend.Write(data); err != nil {
		serviceLogger(fmt.Sprintf("无法传输到后端(HTTPS), %v", err), 31, false)
		return
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	conChk := make(chan struct{})
	go ioReflector(ctx, backend, conn, false, conChk, raddr, dst)
	go ioReflector(ctx, conn, backend, true, conChk, raddr, dst)
	<-conChk
	// 取消上下文，通知另一个 ioReflector 退出
	cancel()
}

// shouldBlockForwardTarget 在建立后端连接前判断目标地址是否有问题
func shouldBlockForwardTarget(dst string, raddr string) (bool, string) {
	// 从 host:port 中提取 host，后续用于 DNS 解析与 IP 比较
	host, _, err := net.SplitHostPort(dst)
	if err != nil {
		return true, fmt.Sprintf("目标地址格式错误: %v", err)
	}

	// 将来源地址转换为 IP，便于判断“目标 IP 和来源 IP 相同”的场景
	srcIP := extractIPFromAddr(raddr)

	// 解析目标 host，拿到所有候选 IP（支持直接 IP 或域名）
	targetIPs, err := resolveHostIPs(host)
	if err != nil {
		return true, fmt.Sprintf("解析目标地址失败: %v", err)
	}

	// 获取本机所有网卡 IP（含回环），用于识别“目标是否本机”
	localIPs, err := collectLocalIPs()
	if err != nil {
		return true, fmt.Sprintf("获取本机地址失败: %v", err)
	}

	for _, targetIP := range targetIPs {
		// 命中回环/未指定地址（0.0.0.0、::）也视为会导致回流，直接拒绝
		if targetIP.IsLoopback() || targetIP.IsUnspecified() {
			return true, fmt.Sprintf("目标IP是本地保留地址: [%s]", targetIP.String())
		}

		// 如果目标IP属于本机任一网卡地址，说明会转发到自己，直接拒绝
		if isIPInList(targetIP, localIPs) {
			return true, fmt.Sprintf("目标IP是本机地址: [%s]", targetIP.String())
		}

		// 如果目标IP和来源IP相同，说明请求很可能会回流到发起端路径，直接拒绝
		if srcIP != nil && targetIP.Equal(srcIP) {
			return true, fmt.Sprintf("目标IP与来源IP相同: [%s]", targetIP.String())
		}
	}

	// 未命中风险规则时允许继续建立连接
	return false, ""
}

// resolveHostIPs 将 host 解析为 IP 列表；若 host 本身是 IP 则直接返回
func resolveHostIPs(host string) ([]net.IP, error) {
	// 目标是字面量 IP 时无需 DNS 查询
	if ip := net.ParseIP(host); ip != nil {
		return []net.IP{ip}, nil
	}

	// 目标是域名时查询 A/AAAA 记录
	ips, err := net.LookupIP(host)
	if err != nil {
		return nil, err
	}
	if len(ips) == 0 {
		return nil, fmt.Errorf("未解析到任何IP")
	}
	return ips, nil
}

// collectLocalIPs 收集本机网卡地址，供“目标是否本机IP”判断使用
func collectLocalIPs() ([]net.IP, error) {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return nil, err
	}

	// 使用 map 去重，避免同一 IP 在不同表示下重复比较
	ipSet := make(map[string]net.IP)
	for _, addr := range addrs {
		switch v := addr.(type) {
		case *net.IPNet:
			if v.IP != nil {
				ipSet[v.IP.String()] = v.IP
			}
		case *net.IPAddr:
			if v.IP != nil {
				ipSet[v.IP.String()] = v.IP
			}
		}
	}

	localIPs := make([]net.IP, 0, len(ipSet))
	for _, ip := range ipSet {
		localIPs = append(localIPs, ip)
	}
	//serviceLogger(fmt.Sprintf("本机网卡IP列表: %v", localIPs), 36, true)
	return localIPs, nil
}

// extractIPFromAddr 从 host:port 中提取 IP；无法解析时返回 nil
func extractIPFromAddr(addr string) net.IP {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return nil
	}
	return net.ParseIP(host)
}

// isIPInList 判断目标 IP 是否出现在给定 IP 列表中
func isIPInList(target net.IP, list []net.IP) bool {
	for _, ip := range list {
		if target.Equal(ip) {
			return true
		}
	}
	return false
}

// ioReflector 函数接收一个 io.WriteCloser 类型的写入对象 dst、一个 io.Reader 类型的读取对象 src、一个 bool 类型的 isToClient、一个 chan struct{} 类型的 conChk，以及两个字符串类型的 raddr 和 dsts
// 该函数使用 io.Copy 函数将 src 中读取到的数据流复制到 dst 中，然后将转发的字节数写入日志
// 最后，该函数关闭 dst 连接，并向 conChk 通道发送一个信号以表示连接已关闭。
func ioReflector(ctx context.Context, dst io.WriteCloser, src io.Reader, isToClient bool, conChk chan struct{}, raddr string, dsts string) {
	// 将 IO 流反映到另一个
	defer onDisconnect(dst, conChk)

	done := make(chan struct{})
	go func() {
		written, _ := io.Copy(dst, src)
		if isToClient {
			serviceLogger(fmt.Sprintf("[%v] -> [%v] %d bytes", dsts, raddr, written), 33, true)
		} else {
			serviceLogger(fmt.Sprintf("[%v] -> [%v] %d bytes", raddr, dsts, written), 33, true)
		}
		close(done)
	}()

	select {
	case <-ctx.Done():
		// 上下文取消，退出
	case <-done:
		// 复制完成，退出
	}
}

// onDisconnect 函数接收一个 io.WriteCloser 类型的写入对象 dst 和一个 chan struct{} 类型的 conChk
// 该函数在 dst 连接关闭时被调用，并向 conChk 通道发送一个信号以表示连接已关闭
func onDisconnect(dst io.WriteCloser, conChk chan struct{}) {
	// 关闭时 -> 强制断开另一对连接
	dst.Close()
	select {
	case conChk <- struct{}{}:
	default:
	}
}

// 解析 Client Hello 消息
func (m *clientHelloMsg) unmarshal(data []byte) bool {
	if len(data) < 42 {
		return false
	}
	m.raw = data
	m.vers = uint16(data[4])<<8 | uint16(data[5])
	m.random = data[6:38]
	sessionIDLen := int(data[38])
	if sessionIDLen > 32 || len(data) < 39+sessionIDLen {
		return false
	}
	m.sessionID = data[39 : 39+sessionIDLen]
	data = data[39+sessionIDLen:]
	if len(data) < 2 {
		return false
	}
	// cipherSuiteLen 是密码套件编号的字节数。由于是 uint16，因此数字必须是偶数
	cipherSuiteLen := int(data[0])<<8 | int(data[1])
	if cipherSuiteLen%2 == 1 || len(data) < 2+cipherSuiteLen {
		return false
	}
	numCipherSuites := cipherSuiteLen / 2
	m.cipherSuites = make([]uint16, numCipherSuites)
	for i := 0; i < numCipherSuites; i++ {
		m.cipherSuites[i] = uint16(data[2+2*i])<<8 | uint16(data[3+2*i])
		if m.cipherSuites[i] == scsvRenegotiation {
			m.secureRenegotiationSupported = true
		}
	}
	data = data[2+cipherSuiteLen:]
	if len(data) < 1 {
		return false
	}
	compressionMethodsLen := int(data[0])
	if len(data) < 1+compressionMethodsLen {
		return false
	}
	m.compressionMethods = data[1 : 1+compressionMethodsLen]

	data = data[1+compressionMethodsLen:]

	m.nextProtoNeg = false
	m.serverName = ""
	m.ocspStapling = false
	m.ticketSupported = false
	m.sessionTicket = nil
	m.signatureAndHashes = nil
	m.alpnProtocols = nil
	m.scts = false

	if len(data) == 0 {
		// ClientHello 后面可选地跟着扩展数据
		return true
	}
	if len(data) < 2 {
		return false
	}

	extensionsLength := int(data[0])<<8 | int(data[1])
	data = data[2:]
	if extensionsLength != len(data) {
		return false
	}

	for len(data) != 0 {
		if len(data) < 4 {
			return false
		}
		extension := uint16(data[0])<<8 | uint16(data[1])
		length := int(data[2])<<8 | int(data[3])
		data = data[4:]
		if len(data) < length {
			return false
		}

		switch extension {
		case extensionServerName:
			d := data[:length]
			if len(d) < 2 {
				return false
			}
			namesLen := int(d[0])<<8 | int(d[1])
			d = d[2:]
			if len(d) != namesLen {
				return false
			}
			for len(d) > 0 {
				if len(d) < 3 {
					return false
				}
				nameType := d[0]
				nameLen := int(d[1])<<8 | int(d[2])
				d = d[3:]
				if len(d) < nameLen {
					return false
				}
				if nameType == 0 {
					m.serverName = string(d[:nameLen])
					// SNI 值末尾不能有点
					if strings.HasSuffix(m.serverName, ".") {
						return false
					}
					break
				}
				d = d[nameLen:]
			}
		case extensionNextProtoNeg:
			if length > 0 {
				return false
			}
			m.nextProtoNeg = true
		case extensionStatusRequest:
			m.ocspStapling = length > 0 && data[0] == statusTypeOCSP
		case extensionSupportedCurves:
			// http://tools.ietf.org/html/rfc4492#section-5.5.1
			if length < 2 {
				return false
			}
			l := int(data[0])<<8 | int(data[1])
			if l%2 == 1 || length != l+2 {
				return false
			}
			numCurves := l / 2
			m.supportedCurves = make([]CurveID, numCurves)
			d := data[2:]
			for i := 0; i < numCurves; i++ {
				m.supportedCurves[i] = CurveID(d[0])<<8 | CurveID(d[1])
				d = d[2:]
			}
		case extensionSupportedPoints:
			// http://tools.ietf.org/html/rfc4492#section-5.5.2
			if length < 1 {
				return false
			}
			l := int(data[0])
			if length != l+1 {
				return false
			}
			m.supportedPoints = make([]uint8, l)
			copy(m.supportedPoints, data[1:])
		case extensionSessionTicket:
			// http://tools.ietf.org/html/rfc5077#section-3.2
			m.ticketSupported = true
			m.sessionTicket = data[:length]
		case extensionSignatureAlgorithms:
			// https://tools.ietf.org/html/rfc5246#section-7.4.1.4.1
			if length < 2 || length&1 != 0 {
				return false
			}
			l := int(data[0])<<8 | int(data[1])
			if l != length-2 {
				return false
			}
			n := l / 2
			d := data[2:]
			m.signatureAndHashes = make([]signatureAndHash, n)
			for i := range m.signatureAndHashes {
				m.signatureAndHashes[i].hash = d[0]
				m.signatureAndHashes[i].signature = d[1]
				d = d[2:]
			}
		case extensionRenegotiationInfo:
			if length == 0 {
				return false
			}
			d := data[:length]
			l := int(d[0])
			d = d[1:]
			if l != len(d) {
				return false
			}

			m.secureRenegotiation = d
			m.secureRenegotiationSupported = true
		case extensionALPN:
			if length < 2 {
				return false
			}
			l := int(data[0])<<8 | int(data[1])
			if l != length-2 {
				return false
			}
			d := data[2:length]
			for len(d) != 0 {
				stringLen := int(d[0])
				d = d[1:]
				if stringLen == 0 || stringLen > len(d) {
					return false
				}
				m.alpnProtocols = append(m.alpnProtocols, string(d[:stringLen]))
				d = d[stringLen:]
			}
		case extensionSCT:
			m.scts = true
			if length != 0 {
				return false
			}
		}
		data = data[length:]
	}

	return true
}

// 输出日志
func serviceLogger(log string, color int, isDebug bool) {
	if isDebug && !EnableDebug {
		return
	}
	log = strings.Replace(log, "\n", "", -1)
	log = strings.Join([]string{time.Now().Format("2006/01/02 15:04:05"), " ", log}, "")
	if color == 0 {
		fmt.Printf("%s\n", log)
	} else {
		fmt.Printf("%c[1;0;%dm%s%c[0m\n", 0x1B, color, log, 0x1B)
	}
	if LogFilePath != "" {
		fd, _ := os.OpenFile(LogFilePath, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
		fdContent := strings.Join([]string{log, "\n"}, "")
		buf := []byte(fdContent)
		fd.Write(buf)
		fd.Close()
	}
}
